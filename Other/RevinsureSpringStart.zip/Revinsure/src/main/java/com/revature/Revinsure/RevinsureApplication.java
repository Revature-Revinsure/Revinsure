package com.revature.Revinsure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevinsureApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevinsureApplication.class, args);
	}

}

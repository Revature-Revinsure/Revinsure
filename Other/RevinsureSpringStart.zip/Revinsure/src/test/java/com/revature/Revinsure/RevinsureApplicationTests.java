package com.revature.Revinsure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevinsureApplicationTests {

	@Test
	void contextLoads() {
	}

}
